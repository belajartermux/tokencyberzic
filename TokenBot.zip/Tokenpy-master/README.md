### Login dengan QR

# Ambil token via QR
